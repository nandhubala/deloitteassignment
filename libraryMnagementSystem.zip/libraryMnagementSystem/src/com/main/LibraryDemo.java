package com.main;
import java.util.*;

import com.library.dao.BooksDao;
import com.library.exceptions.BookNameException;
import com.library.model.Books;
import com.library.services.BookImpl;
import com.library.utilities.Utilities;

public class LibraryDemo {

	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		String option;
		//Books book = new Books();
		BookImpl booksImpl = new BookImpl();
		ArrayList<Books> booklist=new ArrayList<Books>();

		
		
		while (true) {
			System.out.println("1. ADD BOOK " + "\n 2.DISPLAY BOOK" + "\n 3.SEARCH BOOK"
					+"\n 4.DELETE"
		+"\n 5.EXIT");
			option = sc.next();
			//System.out.println("Enter no:of books");
			//int num = sc.nextInt();
			switch (option) {
			case "1":
				
			
				// for (int i = 0; i < num; i++) {
				System.out.println("Enter book name");
				String bookName = sc.next();
				
				
				
				System.out.println("Enter book price");
				String bookPrice = sc.next();

				System.out.println("Enter book author");
				String bookAuthor = sc.next();
				 
			
			booksImpl.addBooks(bookName, bookPrice, bookAuthor);
				
			//}
				break;

			case "2": 
				booklist=booksImpl.displayBooks();
				for(Books book:booklist)
					System.out.println(book);
			break;
			case "3": 
				System.out.println("please enter book name:");
				String searchBookName=sc.next();
				booklist=booksImpl.searchBooks(searchBookName);
				
				for(Books book:booklist)
					System.out.println(book);
			break;
			case "4":
				System.out.println("Please enter the book id you want to delete");
				int deleteBook=sc.nextInt();
				booklist=booksImpl.deleteBooks(deleteBook);
		
				for(Books book:booklist)
					System.out.println(book);
			break;
				
			case "5":System.exit(0);
			break;

			}

		}

	}

}