package com.library.utilities;

import com.library.exceptions.BookNameException;

public class Utilities {
	public static void nameValidation(String bookName) throws BookNameException {
		String pattern = "^[A-Za-z]+$";
		if (!bookName.matches(pattern)) {
			throw new BookNameException("Name can only be in alphabets");
		}

	}

}
