package com.library.services;
import com.library.model.Books;
import java.util.*;

public interface BooksInterface {
	
	public Books addBooks(String bookName,String bookPrice,String authorName);
	
	public ArrayList<Books> displayBooks();
	public ArrayList<Books> searchBooks(String BookName);
	public ArrayList<Books> deleteBooks(int BookId);
}

    