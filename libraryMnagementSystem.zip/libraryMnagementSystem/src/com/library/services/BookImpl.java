package com.library.services;

import java.util.ArrayList;
import java.util.List;

import com.library.dao.BooksDao;
import com.library.exceptions.BookNameException;
import com.library.model.Books;
import com.library.utilities.Utilities;

public class BookImpl implements BooksInterface {

	// BookImpl b=new BookImpl();

	@Override
	public Books addBooks(String bookName, String bookPrice, String authorName) {

		Books book = new Books();

		book.setBookId(Books.getCounter());

		book.setBookName(bookName);
		try {
			Utilities.nameValidation(bookName);
		} catch (BookNameException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

		book.setBookPrice(Double.parseDouble(bookPrice));

		book.setBookAuthor(authorName);

		return book;

	}

	public ArrayList<Books> displayBooks() {

		return BooksDao.displayBooks();
		// return book;

	}

	@Override
	public ArrayList<Books> searchBooks(String BookName) {
		// TODO Auto-generated method stub
		return BooksDao.searchBooks(BookName);

	}

	@Override
	public ArrayList<Books> deleteBooks(int BookId) {
		// TODO Auto-generated method stub
		return BooksDao.deleteBooks(BookId);
	}

}
