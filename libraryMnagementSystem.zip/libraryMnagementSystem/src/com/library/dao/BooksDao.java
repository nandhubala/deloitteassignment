package com.library.dao;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.library.model.Books;
import java.util.*;
import java.sql.Connection;

public class BooksDao {
	
	public static Connection connectTODB() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static void addBooks(Books book) {
		System.out.println(book);

		try {
			Connection con = connectTODB();
			PreparedStatement stmt = con.prepareStatement("insert into Books values(?,?,?,?)");
			stmt.setInt(1, book.getBookId());
			stmt.setString(2, book.getBookName());
			stmt.setDouble(3, book.getBookPrice());
			stmt.setString(4, book.getBookAuthor());
			
			int affectedRows = stmt.executeUpdate();
			System.out.println("affectedRows=" + affectedRows);
			con.close();
		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static ArrayList<Books> displayBooks()
	{
		ArrayList<Books> bookList=new ArrayList<Books>();
		try {
			
			// Statement stmt = connectToDB().createStatement();
			Connection con=connectTODB();
			PreparedStatement stmt = con.prepareStatement("select * from books");
			
			// Step 4: Execute SQL Query
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				Books book=new Books();
				book.setBookId(rs.getInt(1));
				book.setBookName(rs.getString(2));
				book.setBookPrice(rs.getDouble(3));
				book.setBookAuthor(rs.getString(4));
				
				bookList.add(book);
			}
			//Step 5:Close Connection
			con.close();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bookList;
		
	}
	public static ArrayList<Books> searchBooks(String bookName)
	{
		ArrayList<Books> bookList=new ArrayList<Books>();
		try {
			
			// Statement stmt = connectToDB().createStatement();
			Connection con=connectTODB();
			PreparedStatement stmt = con.prepareStatement("select * from books where name=?");
			stmt.setString(1, bookName);
			
			// Step 4: Execute SQL Query
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				Books book=new Books();
				book.setBookId(rs.getInt(1));
				book.setBookName(rs.getString(2));
				book.setBookPrice(rs.getDouble(3));
				book.setBookAuthor(rs.getString(4));
				
				bookList.add(book);
			}
			//Step 5:Close Connection
			con.close();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bookList;
		
	}
	public static ArrayList<Books> deleteBooks(int bookId)
	{
		ArrayList<Books> bookList=new ArrayList<Books>();
		try {
			
			// Statement stmt = connectToDB().createStatement();
			Connection con=connectTODB();
			PreparedStatement stmt = con.prepareStatement("select * from books where BookId=?");
			stmt.setInt(1, bookId);
			
			// Step 4: Execute SQL Query
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				Books book=new Books();
				book.setBookId(rs.getInt(1));
				book.setBookName(rs.getString(2));
				book.setBookPrice(rs.getDouble(3));
				book.setBookAuthor(rs.getString(4));
				
				bookList.add(book);
			}
			//Step 5:Close Connection
			con.close();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bookList;
		
	}

}