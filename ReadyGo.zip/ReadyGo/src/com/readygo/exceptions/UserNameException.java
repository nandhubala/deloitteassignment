package com.readygo.exceptions;

import com.readygo.utilities.*;

public class UserNameException extends Exception {
	public String detailMessage;
	public UserNameException(String message)
	{
		this.detailMessage=message;
	}
	public String getMessage()
	{
		return detailMessage;
	}
	public void Exception(String message)
	{
		this.detailMessage=message;
	}
	public String getMessagepwd()
	{
		return detailMessage;
	}
	
}



	