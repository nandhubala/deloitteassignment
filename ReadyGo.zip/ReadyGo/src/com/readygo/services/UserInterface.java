package com.readygo.services;

import java.util.ArrayList;
import java.util.List;

import com.readygo.model.User;

public interface UserInterface {
	
		public void addUser(String fName, String lName, String contact, String eMail, String address, String cityName,
				String password, String userRole);
		public ArrayList<User> displayBooks();
		public boolean signIn(String userEmail, String userPass);
		
	}
