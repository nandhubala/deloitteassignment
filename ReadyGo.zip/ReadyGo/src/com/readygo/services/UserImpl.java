package com.readygo.services;

import java.util.ArrayList;

import com.readygo.dao.UserDao;
import com.readygo.model.User;





public class UserImpl {

	public void addUser(String fName, String lName, String contact, String eMail, String address, String cityName,
			String password, String userRole) {
		// TODO Auto-generated method stub
		User user = new User();
		user.setUserId(UserDao.getCounter());
		user.setUserFName(fName);
		user.setUserLName(lName);
		user.setContact(Long.parseLong(contact));
		user.setEmail(eMail);
		user.setAddress(address);
		user.setCity(cityName);
		user.setPassword(password);
		user.setRole(Boolean.parseBoolean(userRole));
		
		UserDao.addUser(user);
		
	}

	public ArrayList<User> displayBooks() {
		// TODO Auto-generated method stub
		return UserDao.displayUsers();
	}

	public void signIn(String userEmail, String userPass) {
		// TODO Auto-generated method stub
		UserDao.checkUser(userEmail, userPass);
	}

}
