package com.readygo.utilities;

import com.readygo.exceptions.UserNameException;


public class Utilities {
	public static void nameValidation(String userfname, String userlname) throws UserNameException
	{
String pattern="^[A-Za-z]+$";
if(!userfname.matches(pattern))
{
	if(!userlname.matches(pattern))
	{
	throw new UserNameException("Name can only be in alphabets");
}	
}
	}
	public static void passwordValidation(String pwd) throws Exception
	{
		String pattern="[A-za-z]+[0-9]+[@!#$&]";
		if(!pwd.matches(pattern))
		{
			throw new Exception("Password must contain atleast a number, a capital and a small letter and special charatcters");
		}
	}


	
	}
